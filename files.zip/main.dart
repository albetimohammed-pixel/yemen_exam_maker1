import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:screenshot/screenshot.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const App());

const letters = ['أ', 'ب', 'ج', 'د', 'هـ', 'و', 'ز', 'ح', 'ط', 'ي'];
const ordinals = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر'];
const typeNames = {
  QType.text: 'مقالي / أسطر إجابة',
  QType.complete: 'أكمل الفراغات',
  QType.mcq: 'اختر الإجابة الصحيحة',
  QType.trueFalse: 'صح أو خطأ',
  QType.table: 'جدول',
};

enum QType { text, complete, mcq, trueFalse, table }

class Q {
  QType type;
  String title;
  int marks;
  int lines;
  List<String> items;
  List<List<String>> table;
  Q({required this.type, this.title = '', this.marks = 5, this.lines = 3, List<String>? items, List<List<String>>? table})
      : items = items ?? [''],
        table = table ?? List.generate(3, (_) => List.filled(3, ''));

  Map<String, dynamic> toJson() => {'type': type.index, 'title': title, 'marks': marks, 'lines': lines, 'items': items, 'table': table};
  factory Q.fromJson(Map<String, dynamic> j) => Q(
        type: QType.values[j['type']],
        title: j['title'],
        marks: j['marks'],
        lines: j['lines'],
        items: List<String>.from(j['items']),
        table: (j['table'] as List).map((r) => List<String>.from(r)).toList(),
      );
}

class Exam {
  String school = 'مدرسة ...', title = 'اختبار الفصل الدراسي الأول', time = 'ساعة ونصف', grade = 'الصف: ...', subject = 'المادة: ...', section = '';
  bool compact = false;
  List<Q> qs = [];

  Map<String, dynamic> toJson() => {'school': school, 'title': title, 'time': time, 'grade': grade, 'subject': subject, 'section': section, 'compact': compact, 'qs': qs.map((e) => e.toJson()).toList()};
  void load(Map<String, dynamic> j) {
    school = j['school']; title = j['title']; time = j['time']; grade = j['grade']; subject = j['subject']; section = j['section']; compact = j['compact'];
    qs = (j['qs'] as List).map((e) => Q.fromJson(e)).toList();
  }
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Yemen Exam Maker',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final exam = Exam();

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      final s = p.getString('exam');
      if (s != null) setState(() => exam.load(jsonDecode(s)));
    });
  }

  void msg(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> save() async {
    (await SharedPreferences.getInstance()).setString('exam', jsonEncode(exam.toJson()));
    msg('تم حفظ الاختبار');
  }

  Future<Uint8List> png() => ScreenshotController().captureFromLongWidget(
        InheritedTheme.captureAll(context, Material(child: MediaQuery(data: MediaQuery.of(context), child: ExamPaper(exam)))),
        pixelRatio: 3,
        constraints: const BoxConstraints(maxWidth: 595),
        delay: const Duration(milliseconds: 200),
      );

  Future<Uint8List> pdfBytes() async {
    final img = pw.MemoryImage(await png());
    final doc = pw.Document();
    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(12),
      build: (_) => pw.Align(alignment: pw.Alignment.topCenter, child: pw.Image(img, fit: pw.BoxFit.fitWidth)),
    ));
    return doc.save();
  }

  Future<void> run(Future<void> Function() f) async {
    try {
      await f();
    } catch (e) {
      msg('حدث خطأ: $e');
    }
  }

  Future<void> addQ() async {
    final type = await showDialog<QType>(
      context: context,
      builder: (c) => SimpleDialog(
        title: const Text('نوع السؤال'),
        children: [for (final t in QType.values) SimpleDialogOption(onPressed: () => Navigator.pop(c, t), child: Text(typeNames[t]!))],
      ),
    );
    if (type == null) return;
    final q = await editQ(context, Q(type: type, title: type == QType.table ? 'املأ الجدول الآتي:' : ''));
    if (q != null) setState(() => exam.qs.add(q));
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('مصمم الاختبارات'),
          actions: [
            IconButton(tooltip: 'حفظ', icon: const Icon(Icons.save), onPressed: save),
            IconButton(tooltip: 'طباعة', icon: const Icon(Icons.print), onPressed: () => run(() async => Printing.layoutPdf(onLayout: (_) => pdfBytes()))),
            IconButton(tooltip: 'PDF', icon: const Icon(Icons.picture_as_pdf), onPressed: () => run(() async => Printing.sharePdf(bytes: await pdfBytes(), filename: 'exam.pdf'))),
            IconButton(
              tooltip: 'صورة PNG',
              icon: const Icon(Icons.image),
              onPressed: () => run(() async => Share.shareXFiles([XFile.fromData(await png(), mimeType: 'image/png', name: 'exam.png')])),
            ),
          ],
          bottom: const TabBar(tabs: [Tab(text: 'التحرير'), Tab(text: 'المعاينة')]),
        ),
        floatingActionButton: FloatingActionButton.extended(onPressed: addQ, icon: const Icon(Icons.add), label: const Text('سؤال')),
        body: TabBarView(children: [editor(), preview()]),
      ),
    );
  }

  Widget preview() => LayoutBuilder(
        builder: (c, box) => InteractiveViewer(
          constrained: false,
          minScale: 0.3,
          child: SizedBox(width: 595, child: ExamPaper(exam)),
        ),
      );

  Widget field(String label, String v, void Function(String) f) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: TextFormField(initialValue: v, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), isDense: true), onChanged: (s) => setState(() => f(s))),
      );

  Widget editor() => ListView(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
        children: [
          field('اسم المدرسة', exam.school, (s) => exam.school = s),
          field('عنوان الاختبار', exam.title, (s) => exam.title = s),
          Row(children: [
            Expanded(child: field('الزمن', exam.time, (s) => exam.time = s)),
            const SizedBox(width: 8),
            Expanded(child: field('الشعبة', exam.section, (s) => exam.section = s)),
          ]),
          Row(children: [
            Expanded(child: field('الصف', exam.grade, (s) => exam.grade = s)),
            const SizedBox(width: 8),
            Expanded(child: field('المادة', exam.subject, (s) => exam.subject = s)),
          ]),
          SwitchListTile(title: const Text('تصغير ارتفاع الكليشة'), value: exam.compact, onChanged: (v) => setState(() => exam.compact = v)),
          const Divider(),
          if (exam.qs.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('لا توجد أسئلة بعد. اضغط (سؤال) للإضافة'))),
          for (int i = 0; i < exam.qs.length; i++)
            Card(
              child: ListTile(
                title: Text('السؤال ${ordinals[i % 10]}: ${typeNames[exam.qs[i].type]}'),
                subtitle: Text('${exam.qs[i].title}  •  ${exam.qs[i].marks} درجات', maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () async {
                  final q = await editQ(context, exam.qs[i]);
                  if (q != null) setState(() => exam.qs[i] = q);
                },
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(icon: const Icon(Icons.arrow_upward), onPressed: i == 0 ? null : () => setState(() => exam.qs.insert(i - 1, exam.qs.removeAt(i)))),
                  IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => setState(() => exam.qs.removeAt(i))),
                ]),
              ),
            ),
        ],
      );
}

Future<Q?> editQ(BuildContext context, Q src) {
  final q = Q(type: src.type, title: src.title, marks: src.marks, lines: src.lines, items: [...src.items], table: src.table.map((r) => [...r]).toList());
  return showDialog<Q>(
    context: context,
    builder: (c) => StatefulBuilder(
      builder: (c, set) {
        final listType = q.type == QType.complete || q.type == QType.mcq || q.type == QType.trueFalse;
        void resize(int rows, int cols) {
          q.table = List.generate(rows, (r) => List.generate(cols, (k) => r < q.table.length && k < q.table[r].length ? q.table[r][k] : ''));
          set(() {});
        }

        return AlertDialog(
          title: Text(typeNames[q.type]!),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView(shrinkWrap: true, children: [
              TextFormField(initialValue: q.title, decoration: const InputDecoration(labelText: 'نص السؤال'), onChanged: (s) => q.title = s),
              TextFormField(initialValue: '${q.marks}', decoration: const InputDecoration(labelText: 'الدرجة'), keyboardType: TextInputType.number, onChanged: (s) => q.marks = int.tryParse(s) ?? 0),
              if (q.type == QType.text) ...[
                const SizedBox(height: 12),
                Text('عدد الأسطر: ${q.lines}'),
                Slider(value: q.lines.toDouble(), min: 1, max: 6, divisions: 5, onChanged: (v) => set(() => q.lines = v.round())),
              ],
              if (listType) ...[
                const SizedBox(height: 12),
                Text(q.type == QType.mcq ? 'الخيارات' : q.type == QType.trueFalse ? 'العبارات' : 'الفقرات (استخدم ..... للفراغ)'),
                for (int i = 0; i < q.items.length; i++)
                  Row(children: [
                    Text('${letters[i % 10]}) '),
                    Expanded(child: TextFormField(key: ValueKey('i$i${q.items.length}'), initialValue: q.items[i], onChanged: (s) => q.items[i] = s)),
                    IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: q.items.length > 1 ? () => set(() => q.items.removeAt(i)) : null),
                  ]),
                TextButton.icon(onPressed: () => set(() => q.items.add('')), icon: const Icon(Icons.add), label: const Text('إضافة')),
              ],
              if (q.type == QType.table) ...[
                const SizedBox(height: 12),
                Row(children: [
                  const Text('الأسطر'),
                  IconButton(icon: const Icon(Icons.remove), onPressed: q.table.length > 1 ? () => resize(q.table.length - 1, q.table[0].length) : null),
                  Text('${q.table.length}'),
                  IconButton(icon: const Icon(Icons.add), onPressed: () => resize(q.table.length + 1, q.table[0].length)),
                  const Spacer(),
                  const Text('الأعمدة'),
                  IconButton(icon: const Icon(Icons.remove), onPressed: q.table[0].length > 1 ? () => resize(q.table.length, q.table[0].length - 1) : null),
                  Text('${q.table[0].length}'),
                  IconButton(icon: const Icon(Icons.add), onPressed: () => resize(q.table.length, q.table[0].length + 1)),
                ]),
                for (int r = 0; r < q.table.length; r++)
                  Row(children: [
                    for (int k = 0; k < q.table[r].length; k++)
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(2),
                          child: TextFormField(
                            key: ValueKey('t$r-$k-${q.table.length}-${q.table[0].length}'),
                            initialValue: q.table[r][k],
                            decoration: const InputDecoration(isDense: true, border: OutlineInputBorder()),
                            onChanged: (s) => q.table[r][k] = s,
                          ),
                        ),
                      ),
                  ]),
              ],
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(c, q), child: const Text('حفظ')),
          ],
        );
      },
    ),
  );
}

/// ورقة الاختبار (تُعرض في المعاينة وتُلتقط كصورة للطباعة والتصدير)
class ExamPaper extends StatelessWidget {
  final Exam e;
  const ExamPaper(this.e, {super.key});

  static const bd = BorderSide(color: Colors.black, width: 1.2);

  @override
  Widget build(BuildContext context) {
    final pad = e.compact ? 4.0 : 12.0;
    const base = TextStyle(color: Colors.black, fontSize: 14, height: 1.5);
    final total = e.qs.fold<int>(0, (s, q) => s + q.marks);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTextStyle(
        style: base,
        child: Container(
          color: Colors.white,
          padding: const EdgeInsets.all(16),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            // الكليشة
            Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
              Expanded(child: Text('${e.school}\nالزمن: ${e.time}', style: const TextStyle(fontWeight: FontWeight.bold))),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 14, vertical: pad / 2 + 2),
                decoration: BoxDecoration(border: Border.all(width: 2), borderRadius: BorderRadius.circular(10)),
                child: Text(e.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              ),
              Expanded(child: Text('${e.grade}\n${e.subject}', textAlign: TextAlign.left, style: const TextStyle(fontWeight: FontWeight.bold))),
            ]),
            SizedBox(height: pad),
            Row(children: [
              const Text('اسم الطالب: '),
              Expanded(child: Container(height: 18, decoration: const BoxDecoration(border: Border(bottom: BorderSide(style: BorderStyle.solid))))),
              const SizedBox(width: 16),
              Text('الشعبة: ${e.section.isEmpty ? '........' : e.section}'),
            ]),
            SizedBox(height: pad),
            // جدول الأسئلة
            Table(
              border: TableBorder.all(width: 1.2),
              columnWidths: const {0: FlexColumnWidth(), 1: FixedColumnWidth(60)},
              children: [
                TableRow(decoration: BoxDecoration(color: Colors.grey.shade300), children: [
                  const Padding(padding: EdgeInsets.all(4), child: Text('الأسئلة', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold))),
                  const Padding(padding: EdgeInsets.all(4), child: Text('الدرجة', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold))),
                ]),
                for (int i = 0; i < e.qs.length; i++)
                  TableRow(children: [
                    Padding(padding: const EdgeInsets.all(8), child: _question(e.qs[i], i)),
                    Center(child: Text('${e.qs[i].marks}', style: const TextStyle(fontWeight: FontWeight.bold))),
                  ]),
                TableRow(children: [
                  const Padding(padding: EdgeInsets.all(4), child: Text('المجموع', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold))),
                  Center(child: Text('$total', style: const TextStyle(fontWeight: FontWeight.bold))),
                ]),
              ],
            ),
            const SizedBox(height: 10),
            const Center(child: Text('مع أطيب التمنيات بالنجاح والتوفيق', style: TextStyle(fontWeight: FontWeight.bold))),
          ]),
        ),
      ),
    );
  }

  Widget _question(Q q, int i) {
    final head = Text('السؤال ${ordinals[i % 10]}: ${q.title}', style: const TextStyle(fontWeight: FontWeight.bold));
    Widget body;
    switch (q.type) {
      case QType.text:
        body = Column(children: [for (int k = 0; k < q.lines; k++) Container(height: 26, decoration: const BoxDecoration(border: Border(bottom: BorderSide(width: 0.8))))]);
        break;
      case QType.complete:
        body = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [for (int k = 0; k < q.items.length; k++) Text('${letters[k % 10]}) ${q.items[k]} ..........................')],
        );
        break;
      case QType.mcq:
        body = Wrap(spacing: 24, children: [for (int k = 0; k < q.items.length; k++) Text('${letters[k % 10]}) ${q.items[k]}')]);
        break;
      case QType.trueFalse:
        body = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [for (int k = 0; k < q.items.length; k++) Text('${letters[k % 10]}) ${q.items[k]}  (        )')],
        );
        break;
      case QType.table:
        body = Table(
          border: TableBorder.all(),
          children: [
            for (final r in q.table)
              TableRow(children: [for (final cell in r) Padding(padding: const EdgeInsets.all(4), child: Text(cell, textAlign: TextAlign.center))]),
          ],
        );
        break;
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [head, const SizedBox(height: 4), body]);
  }
}

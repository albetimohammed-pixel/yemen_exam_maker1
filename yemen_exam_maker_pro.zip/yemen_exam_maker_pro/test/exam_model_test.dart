import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:yemen_exam_maker/models/exam.dart';

void main() {
  test('الاختبار يُحفظ ويُسترجع من JSON بدون فقدان', () {
    final exam = Exam.create();
    exam.header.school = 'مدرسة الأمل';
    exam.questions.addAll([
      Question(type: QType.mcq, text: 'اختر', score: 2, items: ['أ', 'ب', 'ج'], correctIndex: 1, tfAnswers: [true, true, true]),
      Question(type: QType.trueFalse, text: 'صح أم خطأ', score: 3, items: ['س', 'ص'], tfAnswers: [true, false]),
      Question(type: QType.table, text: 'جدول', score: 1.5, table: [['م', 'الاسم'], ['', '']]),
    ]);

    final copy = Exam.fromJson(jsonDecode(jsonEncode(exam.toJson())) as Map<String, dynamic>);

    expect(copy.header.school, 'مدرسة الأمل');
    expect(copy.questions.length, 3);
    expect(copy.questions[0].correctIndex, 1);
    expect(copy.questions[1].tfAnswers, [true, false]);
    expect(copy.questions[2].table[0][1], 'الاسم');
    expect(copy.total, 6.5);
  });

  test('تحويل الأرقام العربية وتنسيق الدرجات', () {
    expect(normDigits('١٢٫٥'), '12.5');
    expect(fmtScore(5), '5');
    expect(fmtScore(2.5), '2.5');
  });

  test('نسخ السؤال يعطي معرّفاً جديداً', () {
    final q = Question(type: QType.essay, text: 'س');
    final c = q.copy();
    expect(c.id, isNot(q.id));
    expect(c.text, 'س');
  });
}

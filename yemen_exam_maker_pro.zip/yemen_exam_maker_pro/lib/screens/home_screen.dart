import 'package:flutter/material.dart';

import '../models/exam.dart';
import '../services/exam_repository.dart';
import 'about_screen.dart';
import 'editor_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Exam> _exams = [];
  bool _loading = true;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await ExamRepository.instance.loadAll();
    if (!mounted) return;
    setState(() {
      _exams = list;
      _loading = false;
    });
  }

  Future<void> _open(Exam exam) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => EditorScreen(exam: exam)),
    );
    _load();
  }

  Future<void> _duplicate(Exam exam) async {
    final copy = Exam.fromJson(exam.toJson())..id = newId();
    await ExamRepository.instance.upsert(copy);
    _load();
  }

  Future<void> _delete(Exam exam) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الاختبار'),
        content: Text('هل تريد حذف «${exam.title}» نهائياً؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
        ],
      ),
    );
    if (ok == true) {
      await ExamRepository.instance.delete(exam.id);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = _query.trim();
    final shown = q.isEmpty
        ? _exams
        : _exams
            .where((e) =>
                e.title.contains(q) ||
                e.header.school.contains(q) ||
                e.header.examTitle.contains(q))
            .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('صانع الاختبارات اليمنية'),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            tooltip: 'عن التطبيق',
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const AboutScreen())),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _open(Exam.create()),
        icon: const Icon(Icons.add),
        label: const Text('اختبار جديد'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                if (_exams.length > 3)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                    child: TextField(
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        hintText: 'ابحث في اختباراتك',
                      ),
                      onChanged: (v) => setState(() => _query = v),
                    ),
                  ),
                Expanded(
                  child: shown.isEmpty
                      ? _empty()
                      : ListView.builder(
                          padding: const EdgeInsets.fromLTRB(16, 12, 16, 90),
                          itemCount: shown.length,
                          itemBuilder: (_, i) => _card(shown[i]),
                        ),
                ),
              ],
            ),
    );
  }

  Widget _empty() => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.assignment_outlined,
                  size: 76, color: Theme.of(context).colorScheme.outline),
              const SizedBox(height: 12),
              Text(
                _exams.isEmpty
                    ? 'لا توجد اختبارات محفوظة.\nاضغط «اختبار جديد» للبدء.'
                    : 'لا توجد نتائج مطابقة.',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 15, color: Theme.of(context).colorScheme.outline),
              ),
            ],
          ),
        ),
      );

  Widget _card(Exam e) {
    final d = e.updated;
    final sub = [
      if (e.header.school.isNotEmpty) e.header.school,
      '${e.questions.length} سؤال • ${fmtScore(e.total)} درجة',
      '${d.year}/${d.month}/${d.day}',
    ].join('  |  ');
    return Card(
      child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.description)),
        title: Text(e.title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(sub),
        onTap: () => _open(e),
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'edit') _open(e);
            if (v == 'dup') _duplicate(e);
            if (v == 'del') _delete(e);
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'edit', child: Text('فتح وتعديل')),
            PopupMenuItem(value: 'dup', child: Text('تكرار')),
            PopupMenuItem(value: 'del', child: Text('حذف')),
          ],
        ),
      ),
    );
  }
}

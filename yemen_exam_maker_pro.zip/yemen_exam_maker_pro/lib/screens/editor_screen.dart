import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:printing/printing.dart';

import '../models/exam.dart';
import '../services/exam_repository.dart';
import '../services/pdf_service.dart';
import 'question_editor_page.dart';

IconData iconForType(QType t) {
  switch (t) {
    case QType.essay:
      return Icons.edit_note;
    case QType.complete:
      return Icons.more_horiz;
    case QType.mcq:
      return Icons.checklist;
    case QType.trueFalse:
      return Icons.rule;
    case QType.table:
      return Icons.table_chart_outlined;
    case QType.matching:
      return Icons.compare_arrows;
  }
}

class EditorScreen extends StatefulWidget {
  final Exam exam;
  const EditorScreen({super.key, required this.exam});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> with SingleTickerProviderStateMixin {
  late final TabController _tab;
  Exam get e => widget.exam;
  Timer? _timer;
  bool _dirty = false;

  static const _frameColors = [
    0xFF1B5E20, 0xFF000000, 0xFF0D47A1, 0xFF880E4F, 0xFF4E342E, 0xFF4A148C, 0xFFB71C1C,
  ];

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 4, vsync: this);
    // لإظهار زر «إضافة سؤال» فقط في تبويب الأسئلة
    _tab.addListener(() => setState(() {}));
  }

  /// أي تعديل يمرّ من هنا: تحديث الواجهة + حفظ تلقائي بعد توقف الكتابة
  void _changed([VoidCallback? fn]) {
    setState(() => fn?.call());
    _dirty = true;
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 600), _save);
  }

  Future<void> _save() async {
    if (!_dirty) return;
    _dirty = false;
    await ExamRepository.instance.upsert(e);
  }

  @override
  void dispose() {
    _timer?.cancel();
    if (_dirty) ExamRepository.instance.upsert(e);
    _tab.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  // ------------------------------------------------------------------ الأسئلة
  Future<void> _addQuestion() async {
    final type = await showModalBottomSheet<QType>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Text('اختر نوع السؤال',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
            for (final t in QType.values)
              ListTile(
                leading: Icon(iconForType(t)),
                title: Text(t.title),
                subtitle: Text(t.hint),
                onTap: () => Navigator.pop(ctx, t),
              ),
          ],
        ),
      ),
    );
    if (type == null || !mounted) return;
    final q = await Navigator.push<Question>(
      context,
      MaterialPageRoute(
          builder: (_) => QuestionEditorPage(question: Question.blank(type), isNew: true)),
    );
    if (q != null) _changed(() => e.questions.add(q));
  }

  Future<void> _editQuestion(int i) async {
    final q = await Navigator.push<Question>(
      context,
      MaterialPageRoute(builder: (_) => QuestionEditorPage(question: e.questions[i])),
    );
    if (q != null) _changed(() => e.questions[i] = q);
  }

  // ------------------------------------------------------------------ الشعار
  Future<void> _pickLogo() async {
    try {
      final x = await ImagePicker().pickImage(
          source: ImageSource.gallery, maxWidth: 500, imageQuality: 85);
      if (x == null) return;
      final bytes = await x.readAsBytes();
      _changed(() => e.header.logo = base64Encode(bytes));
    } catch (_) {
      _snack('تعذّر اختيار الصورة');
    }
  }

  // ------------------------------------------------------------------ التصدير
  Future<void> _shareAnswerKey() async {
    try {
      final bytes = await PdfService.build(e, answerKey: true);
      await Printing.sharePdf(bytes: bytes, filename: 'نموذج إجابة - ${e.title}.pdf');
    } catch (err) {
      _snack('تعذّر إنشاء نموذج الإجابة: $err');
    }
  }

  Future<void> _printAnswerKey() async {
    try {
      await Printing.layoutPdf(
        name: 'نموذج إجابة - ${e.title}',
        onLayout: (_) => PdfService.build(e, answerKey: true),
      );
    } catch (err) {
      _snack('تعذّرت الطباعة: $err');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(e.title, overflow: TextOverflow.ellipsis),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'key_share') _shareAnswerKey();
              if (v == 'key_print') _printAnswerKey();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'key_share', child: Text('مشاركة نموذج الإجابة (PDF)')),
              PopupMenuItem(value: 'key_print', child: Text('طباعة نموذج الإجابة')),
            ],
          ),
        ],
        bottom: TabBar(
          controller: _tab,
          indicatorColor: Theme.of(context).colorScheme.onPrimary,
          labelColor: Theme.of(context).colorScheme.onPrimary,
          unselectedLabelColor:
              Theme.of(context).colorScheme.onPrimary.withOpacity(0.65),
          tabs: const [
            Tab(icon: Icon(Icons.badge_outlined), text: 'الترويسة'),
            Tab(icon: Icon(Icons.list_alt), text: 'الأسئلة'),
            Tab(icon: Icon(Icons.tune), text: 'التنسيق'),
            Tab(icon: Icon(Icons.picture_as_pdf), text: 'المعاينة'),
          ],
        ),
      ),
      floatingActionButton: _tab.index == 1
          ? FloatingActionButton.extended(
              onPressed: _addQuestion,
              icon: const Icon(Icons.add),
              label: const Text('إضافة سؤال'),
            )
          : null,
      body: TabBarView(
        controller: _tab,
        // منع السحب الجانبي حتى لا يتعارض مع إعادة ترتيب الأسئلة
        physics: const NeverScrollableScrollPhysics(),
        children: [_headerTab(), _questionsTab(), _settingsTab(), _previewTab()],
      ),
    );
  }

  // ------------------------------------------------------------------ تبويب الترويسة
  Widget _tf(String label, String value, ValueChanged<String> onChanged,
      {int maxLines = 1, String? hint}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        initialValue: value,
        maxLines: maxLines,
        decoration: InputDecoration(labelText: label, hintText: hint),
        onChanged: (v) => _changed(() => onChanged(v)),
      ),
    );
  }

  Widget _title(String t) => Padding(
        padding: const EdgeInsets.only(top: 8, bottom: 10),
        child: Text(t,
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary)),
      );

  Widget _headerTab() {
    final h = e.header;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _title('نمط الكليشة'),
        SegmentedButton<int>(
          showSelectedIcon: false,
          segments: const [
            ButtonSegment(value: 0, label: Text('بيضاوي')),
            ButtonSegment(value: 1, label: Text('كلاسيكي')),
            ButtonSegment(value: 2, label: Text('مبسّط')),
          ],
          selected: {h.style},
          onSelectionChanged: (v) => _changed(() => h.style = v.first),
        ),
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('البسملة أعلى الصفحة'),
          value: h.showBasmala,
          onChanged: (v) => _changed(() => h.showBasmala = v),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('سطر اسم الطالب والشعبة'),
          value: h.showStudentLine,
          onChanged: (v) => _changed(() => h.showStudentLine = v),
        ),
        _title('بيانات المدرسة'),
        _tf('الجمهورية', h.republic, (v) => h.republic = v),
        _tf('الوزارة', h.ministry, (v) => h.ministry = v),
        _tf('المديرية / المكتب', h.directorate, (v) => h.directorate = v),
        _tf('اسم المدرسة', h.school, (v) => h.school = v),
        _tf('اسم المعلم (اختياري)', h.teacher, (v) => h.teacher = v),
        _title('بيانات الاختبار'),
        _tf('عنوان الاختبار', h.examTitle, (v) => h.examTitle = v, hint: 'اختبار الشهر الثاني - الفصل الأول'),
        _tf('العام الدراسي', h.academicYear, (v) => h.academicYear = v),
        _tf('المادة', h.subject, (v) => h.subject = v),
        _tf('الصف', h.grade, (v) => h.grade = v),
        _tf('الشعبة', h.section, (v) => h.section = v),
        _tf('اليوم', h.day, (v) => h.day = v),
        _tf('التاريخ', h.date, (v) => h.date = v),
        _tf('الزمن', h.duration, (v) => h.duration = v),
        _title('الشعار'),
        Row(
          children: [
            if (h.logo != null && h.logo!.isNotEmpty)
              Padding(
                padding: const EdgeInsetsDirectional.only(end: 12),
                child: Image.memory(base64Decode(h.logo!),
                    height: 64, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
              ),
            OutlinedButton.icon(
              onPressed: _pickLogo,
              icon: const Icon(Icons.image_outlined),
              label: Text(h.logo == null ? 'اختيار شعار' : 'تغيير'),
            ),
            if (h.logo != null)
              IconButton(
                tooltip: 'إزالة',
                icon: const Icon(Icons.delete_outline),
                onPressed: () => _changed(() => h.logo = null),
              ),
          ],
        ),
        const SizedBox(height: 4),
        Text('يظهر الشعار في النمط الكلاسيكي، ويمكن استخدامه كعلامة مائية من تبويب التنسيق.',
            style: TextStyle(
                fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
        const SizedBox(height: 40),
      ],
    );
  }

  // ------------------------------------------------------------------ تبويب الأسئلة
  Widget _questionsTab() {
    if (e.questions.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text('لا توجد أسئلة بعد.\nاضغط «إضافة سؤال» لإنشاء أول سؤال.',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 15, color: Theme.of(context).colorScheme.outline)),
        ),
      );
    }
    return Column(
      children: [
        Container(
          width: double.infinity,
          color: Theme.of(context).colorScheme.secondaryContainer,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(
            '${e.questions.length} سؤال  •  المجموع الكلي: ${fmtScore(e.total)} درجة   (اسحب لإعادة الترتيب)',
            style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSecondaryContainer),
          ),
        ),
        Expanded(
          child: ReorderableListView.builder(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
            itemCount: e.questions.length,
            onReorder: (oldIndex, newIndex) => _changed(() {
              if (newIndex > oldIndex) newIndex -= 1;
              final item = e.questions.removeAt(oldIndex);
              e.questions.insert(newIndex, item);
            }),
            itemBuilder: (context, i) {
              final q = e.questions[i];
              return Card(
                key: ValueKey(q.id),
                child: ListTile(
                  onTap: () => _editQuestion(i),
                  leading: CircleAvatar(child: Icon(iconForType(q.type), size: 20)),
                  title: Text('${i + 1}. ${q.text}', maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: Text('${q.type.title}  •  ${fmtScore(q.score)} درجة'),
                  trailing: PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'edit') _editQuestion(i);
                      if (v == 'dup') _changed(() => e.questions.insert(i + 1, q.copy()));
                      if (v == 'del') {
                        final removed = q;
                        _changed(() => e.questions.removeAt(i));
                        ScaffoldMessenger.of(context)
                          ..hideCurrentSnackBar()
                          ..showSnackBar(SnackBar(
                            content: const Text('تم حذف السؤال'),
                            action: SnackBarAction(
                              label: 'تراجع',
                              onPressed: () => _changed(() {
                                final at = i > e.questions.length ? e.questions.length : i;
                                e.questions.insert(at, removed);
                              }),
                            ),
                          ));
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'edit', child: Text('تعديل')),
                      PopupMenuItem(value: 'dup', child: Text('تكرار')),
                      PopupMenuItem(value: 'del', child: Text('حذف')),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // ------------------------------------------------------------------ تبويب التنسيق
  Widget _settingsTab() {
    final s = e.settings;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _title('الإطار'),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('إطار حول الصفحة'),
          value: s.border,
          onChanged: (v) => _changed(() => s.border = v),
        ),
        if (s.border) ...[
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('إطار مزدوج'),
            value: s.doubleBorder,
            onChanged: (v) => _changed(() => s.doubleBorder = v),
          ),
          const Text('لون الإطار'),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            children: [
              for (final c in _frameColors)
                GestureDetector(
                  onTap: () => _changed(() => s.borderColor = c),
                  child: CircleAvatar(
                    radius: 18,
                    backgroundColor: Color(c),
                    child: s.borderColor == c
                        ? const Icon(Icons.check, color: Colors.white, size: 18)
                        : null,
                  ),
                ),
            ],
          ),
        ],
        _title('الخط والترقيم'),
        Text('حجم الخط: ${(s.fontScale * 100).round()}%'),
        Slider(
          value: s.fontScale,
          min: 0.85,
          max: 1.3,
          divisions: 9,
          label: '${(s.fontScale * 100).round()}%',
          onChanged: (v) => _changed(() => s.fontScale = v),
        ),
        const Text('ترقيم الأسئلة'),
        const SizedBox(height: 8),
        SegmentedButton<int>(
          showSelectedIcon: false,
          segments: const [
            ButtonSegment(value: 0, label: Text('أ )  ب )')),
            ButtonSegment(value: 1, label: Text('1 -  2 -')),
            ButtonSegment(value: 2, label: Text('السؤال الأول')),
          ],
          selected: {s.numbering},
          onSelectionChanged: (v) => _changed(() => s.numbering = v.first),
        ),
        _title('النصوص'),
        _tf('سطر التوجيه أعلى الجدول', s.instruction, (v) => s.instruction = v),
        _tf('عبارة الختام', s.closing, (v) => s.closing = v),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('إظهار المجموع الكلي'),
          value: s.showTotal,
          onChanged: (v) => _changed(() => s.showTotal = v),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('إضافة ورقة تظليل (للاختيار والصح/خطأ)'),
          subtitle: const Text('تُضاف كصفحة أخيرة في ملف الطالب'),
          value: s.bubbleSheet,
          onChanged: (v) => _changed(() => s.bubbleSheet = v),
        ),
        _title('العلامة المائية'),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('تفعيل العلامة المائية'),
          value: s.watermark,
          onChanged: (v) => _changed(() => s.watermark = v),
        ),
        if (s.watermark) ...[
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('استخدام الشعار بدل النص'),
            value: s.watermarkUseLogo,
            onChanged: (v) => _changed(() => s.watermarkUseLogo = v),
          ),
          if (!s.watermarkUseLogo)
            _tf('نص العلامة المائية', s.watermarkText, (v) => s.watermarkText = v,
                hint: 'اسم المدرسة'),
          Text('الشفافية: ${(s.watermarkOpacity * 100).round()}%'),
          Slider(
            value: s.watermarkOpacity.clamp(0.02, 0.4).toDouble(),
            min: 0.02,
            max: 0.4,
            onChanged: (v) => _changed(() => s.watermarkOpacity = v),
          ),
        ],
        const SizedBox(height: 40),
      ],
    );
  }

  // ------------------------------------------------------------------ تبويب المعاينة
  Widget _previewTab() {
    return PdfPreview(
      build: (format) => PdfService.build(e),
      canChangePageFormat: false,
      canChangeOrientation: false,
      canDebug: false,
      allowSharing: true,
      allowPrinting: true,
      pdfFileName: '${e.title}.pdf',
      loadingWidget: const CircularProgressIndicator(),
      onError: (context, error) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('تعذّر إنشاء المعاينة:\n$error', textAlign: TextAlign.center),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../models/exam.dart';

/// صفحة تحرير سؤال واحد. تُرجع [Question] جديداً (بنفس المعرّف) عند الحفظ.
class QuestionEditorPage extends StatefulWidget {
  final Question question;
  final bool isNew;
  const QuestionEditorPage({super.key, required this.question, this.isNew = false});

  @override
  State<QuestionEditorPage> createState() => _QuestionEditorPageState();
}

class _QuestionEditorPageState extends State<QuestionEditorPage> {
  late QType _type;
  late final TextEditingController _text;
  late final TextEditingController _score;
  late final TextEditingController _model;
  late int _lines;
  late List<TextEditingController> _items;
  late List<TextEditingController> _items2;
  late List<bool> _tf;
  late int _correct;
  late List<List<TextEditingController>> _grid;
  late bool _header;

  @override
  void initState() {
    super.initState();
    final q = widget.question;
    _type = q.type;
    _text = TextEditingController(text: q.text);
    _score = TextEditingController(text: fmtScore(q.score));
    _model = TextEditingController(text: q.modelAnswer);
    _lines = q.lines.clamp(1, 12).toInt();
    _items = q.items.map((s) => TextEditingController(text: s)).toList();
    _items2 = q.items2.map((s) => TextEditingController(text: s)).toList();
    _tf = List<bool>.generate(
        _items.length, (i) => i < q.tfAnswers.length ? q.tfAnswers[i] : true);
    _correct = q.correctIndex;
    _grid = q.table
        .map((r) => r.map((c) => TextEditingController(text: c)).toList())
        .toList();
    if (_grid.isEmpty) _grid = [[TextEditingController(), TextEditingController()]];
    _header = q.tableHeader;
    _ensureDefaults();
  }

  @override
  void dispose() {
    _text.dispose();
    _score.dispose();
    _model.dispose();
    for (final c in [..._items, ..._items2]) {
      c.dispose();
    }
    for (final r in _grid) {
      for (final c in r) {
        c.dispose();
      }
    }
    super.dispose();
  }

  /// عند تغيير النوع نتأكد أن القوائم لديها عدد مناسب من الحقول
  void _ensureDefaults() {
    void fill(List<TextEditingController> l, int n) {
      while (l.length < n) {
        l.add(TextEditingController());
      }
    }

    final minItems = _type == QType.mcq ? 4 : (_type == QType.essay || _type == QType.table ? 0 : 3);
    fill(_items, minItems);
    if (_type == QType.matching) fill(_items2, 3);
    while (_tf.length < _items.length) {
      _tf.add(true);
    }
  }

  void _snack(String m) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  // ------------------------------------------------------------------ الحفظ
  void _save() {
    final text = _text.text.trim();
    if (text.isEmpty) return _snack('اكتب نص السؤال');
    final score = double.tryParse(normDigits(_score.text.trim()));
    if (score == null || score < 0) return _snack('أدخل درجة صحيحة');

    final items = <String>[];
    final tf = <bool>[];
    var correct = -1;
    for (var i = 0; i < _items.length; i++) {
      final s = _items[i].text.trim();
      if (s.isEmpty) continue;
      if (i == _correct) correct = items.length;
      items.add(s);
      tf.add(_tf[i]);
    }
    final items2 = _items2.map((c) => c.text.trim()).where((s) => s.isNotEmpty).toList();

    switch (_type) {
      case QType.mcq:
        if (items.length < 2) return _snack('أضف خيارين على الأقل');
        break;
      case QType.complete:
      case QType.trueFalse:
        if (items.isEmpty) return _snack('أضف فقرة واحدة على الأقل');
        break;
      case QType.matching:
        if (items.isEmpty || items2.isEmpty) return _snack('املأ عمودي التوصيل');
        break;
      case QType.essay:
      case QType.table:
        break;
    }

    final table = _grid.map((r) => r.map((c) => c.text.trim()).toList()).toList();

    Navigator.pop(
      context,
      Question(
        id: widget.question.id,
        type: _type,
        text: text,
        score: score,
        lines: _lines,
        items: (_type == QType.essay || _type == QType.table) ? [] : items,
        items2: _type == QType.matching ? items2 : [],
        table: table,
        tableHeader: _header,
        correctIndex: _type == QType.mcq ? correct : -1,
        tfAnswers: tf,
        modelAnswer: _model.text.trim(),
      ),
    );
  }

  // ------------------------------------------------------------------ عناصر مساعدة
  Widget _stepper(String label, int value, int min, int max, ValueChanged<int> onChange) {
    return Row(
      children: [
        Text(label),
        const Spacer(),
        IconButton(
          icon: const Icon(Icons.remove_circle_outline),
          onPressed: value > min ? () => onChange(value - 1) : null,
        ),
        SizedBox(
          width: 28,
          child: Text('$value',
              textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        ),
        IconButton(
          icon: const Icon(Icons.add_circle_outline),
          onPressed: value < max ? () => onChange(value + 1) : null,
        ),
      ],
    );
  }

  Widget _sectionTitle(String t) => Padding(
        padding: const EdgeInsets.only(top: 6, bottom: 10),
        child: Text(t,
            style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary)),
      );

  void _removeItem(int i) {
    setState(() {
      _items.removeAt(i).dispose();
      _tf.removeAt(i);
      if (_correct == i) {
        _correct = -1;
      } else if (_correct > i) {
        _correct--;
      }
    });
  }

  void _addItem() {
    setState(() {
      _items.add(TextEditingController());
      _tf.add(true);
    });
  }

  /// صف حقل واحد: (اختياري) زر الإجابة الصحيحة، الحقل، (اختياري) صح/خطأ، حذف
  Widget _itemRow(int i, String label, {bool mcq = false, bool tf = false}) {
    final good = Colors.green.shade700;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          if (mcq)
            IconButton(
              tooltip: 'الإجابة الصحيحة',
              icon: Icon(_correct == i ? Icons.check_circle : Icons.radio_button_unchecked,
                  color: _correct == i ? good : null),
              onPressed: () => setState(() => _correct = _correct == i ? -1 : i),
            ),
          Expanded(
            child: TextField(
              controller: _items[i],
              minLines: 1,
              maxLines: 3,
              decoration: InputDecoration(labelText: '$label ${i + 1}'),
            ),
          ),
          if (tf)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: SegmentedButton<bool>(
                showSelectedIcon: false,
                style: const ButtonStyle(visualDensity: VisualDensity.compact),
                segments: const [
                  ButtonSegment(value: true, label: Text('صح')),
                  ButtonSegment(value: false, label: Text('خطأ')),
                ],
                selected: {_tf[i]},
                onSelectionChanged: (v) => setState(() => _tf[i] = v.first),
              ),
            ),
          IconButton(
            tooltip: 'حذف',
            icon: const Icon(Icons.delete_outline),
            onPressed: _items.length > 1 ? () => _removeItem(i) : null,
          ),
        ],
      ),
    );
  }

  List<Widget> _itemsSection(String label, {bool mcq = false, bool tf = false, int max = 40}) {
    return [
      for (var i = 0; i < _items.length; i++) _itemRow(i, label, mcq: mcq, tf: tf),
      Align(
        alignment: AlignmentDirectional.centerStart,
        child: TextButton.icon(
          icon: const Icon(Icons.add),
          label: Text('إضافة $label'),
          onPressed: _items.length < max ? _addItem : null,
        ),
      ),
    ];
  }

  List<Widget> _matchingSection() {
    return [
      _sectionTitle('العمود الأول (الأرقام)'),
      ..._itemsSection('عنصر', max: 12),
      const Divider(),
      _sectionTitle('العمود الثاني (الحروف)'),
      for (var i = 0; i < _items2.length; i++)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _items2[i],
                  decoration: InputDecoration(labelText: 'عنصر ${i + 1}'),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: _items2.length > 1
                    ? () => setState(() => _items2.removeAt(i).dispose())
                    : null,
              ),
            ],
          ),
        ),
      Align(
        alignment: AlignmentDirectional.centerStart,
        child: TextButton.icon(
          icon: const Icon(Icons.add),
          label: const Text('إضافة عنصر'),
          onPressed:
              _items2.length < 12 ? () => setState(() => _items2.add(TextEditingController())) : null,
        ),
      ),
    ];
  }

  void _resizeGrid(int r, int c) {
    setState(() {
      while (_grid.length > r) {
        for (final x in _grid.removeLast()) {
          x.dispose();
        }
      }
      while (_grid.length < r) {
        _grid.add([]);
      }
      for (final row in _grid) {
        while (row.length > c) {
          row.removeLast().dispose();
        }
        while (row.length < c) {
          row.add(TextEditingController());
        }
      }
    });
  }

  List<Widget> _tableSection() {
    final rows = _grid.length;
    final cols = _grid.isEmpty ? 1 : _grid.first.length;
    return [
      _stepper('عدد الصفوف', rows, 1, 15, (v) => _resizeGrid(v, cols)),
      _stepper('عدد الأعمدة', cols, 1, 6, (v) => _resizeGrid(rows, v)),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('الصف الأول عناوين (بخط عريض)'),
        value: _header,
        onChanged: (v) => setState(() => _header = v),
      ),
      const Text('اترك الخلايا فارغة ليملأها الطالب.', style: TextStyle(fontSize: 12)),
      const SizedBox(height: 8),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Column(
          children: [
            for (var r = 0; r < _grid.length; r++)
              Row(
                children: [
                  for (var c = 0; c < _grid[r].length; c++)
                    Container(
                      width: 120,
                      padding: const EdgeInsets.all(3),
                      child: TextField(
                        controller: _grid[r][c],
                        textAlign: TextAlign.center,
                        decoration: InputDecoration(
                          hintText: (r == 0 && _header) ? 'عنوان' : '',
                          filled: r == 0 && _header,
                        ),
                      ),
                    ),
                ],
              ),
          ],
        ),
      ),
    ];
  }

  void _changeType(QType t) {
    setState(() {
      _type = t;
      _ensureDefaults();
    });
  }

  @override
  Widget build(BuildContext context) {
    final showModel = _type != QType.mcq && _type != QType.trueFalse;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isNew ? 'سؤال جديد' : 'تعديل السؤال'),
        actions: [
          TextButton.icon(
            style: TextButton.styleFrom(
                foregroundColor: Theme.of(context).colorScheme.onPrimary),
            onPressed: _save,
            icon: const Icon(Icons.check),
            label: const Text('حفظ'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DropdownButtonFormField<QType>(
            value: _type,
            decoration: const InputDecoration(labelText: 'نوع السؤال'),
            items: [
              for (final t in QType.values)
                DropdownMenuItem(value: t, child: Text(t.title)),
            ],
            onChanged: (v) {
              if (v != null) _changeType(v);
            },
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _text,
            minLines: 1,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'نص السؤال',
              hintText: 'مثال: اختر الإجابة الصحيحة فيما يأتي:',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _score,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'الدرجة'),
          ),
          const Divider(height: 28),
          if (_type == QType.essay)
            _stepper('عدد أسطر الإجابة', _lines, 1, 12, (v) => setState(() => _lines = v)),
          if (_type == QType.complete) ..._itemsSection('فقرة'),
          if (_type == QType.mcq) ...[
            const Text('اضغط على الدائرة لتحديد الإجابة الصحيحة (تظهر في نموذج الإجابة).',
                style: TextStyle(fontSize: 12)),
            const SizedBox(height: 8),
            ..._itemsSection('خيار', mcq: true, max: 8),
          ],
          if (_type == QType.trueFalse) ..._itemsSection('عبارة', tf: true),
          if (_type == QType.matching) ..._matchingSection(),
          if (_type == QType.table) ..._tableSection(),
          if (showModel) ...[
            const Divider(height: 28),
            TextField(
              controller: _model,
              minLines: 1,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: 'الإجابة النموذجية (اختياري - للمعلم)',
                hintText: 'تظهر في ملف نموذج الإجابة فقط',
              ),
            ),
          ],
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

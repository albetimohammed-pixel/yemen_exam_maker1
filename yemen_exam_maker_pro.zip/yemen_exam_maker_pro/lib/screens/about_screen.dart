import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('عن التطبيق')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 12),
          Center(
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: cs.primary, width: 3),
              ),
              child: const CircleAvatar(
                radius: 64,
                backgroundImage: AssetImage('assets/images/developer.jpg'),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Center(
            child: Text('صانع الاختبارات اليمنية',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 4),
          Center(
            child: Text('الإصدار 2.0.0',
                style: TextStyle(color: cs.onSurfaceVariant)),
          ),
          const SizedBox(height: 20),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'تطبيق للمعلمين لإنشاء أوراق الاختبارات بنمط الكليشة اليمنية، '
                'مع ستة أنواع من الأسئلة، ونموذج إجابة للمعلم، وورقة تظليل، '
                'وتصدير PDF للطباعة والمشاركة. يعمل بدون إنترنت وتُحفظ اختباراتك على جهازك.',
                style: TextStyle(height: 1.7),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

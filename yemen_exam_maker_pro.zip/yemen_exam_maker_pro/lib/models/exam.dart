// نماذج البيانات: الاختبار، الترويسة، إعدادات الصفحة، الأسئلة.
// كل النماذج تدعم toJson/fromJson ليتم حفظها بشكل دائم على الجهاز.

String newId() => DateTime.now().microsecondsSinceEpoch.toString();

/// يعرض الدرجة بدون كسور إذا كانت صحيحة (5 بدل 5.0)
String fmtScore(double v) =>
    v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);

/// تحويل الأرقام العربية-الهندية إلى لاتينية لتحليل الأرقام المُدخلة
String normDigits(String s) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  final b = StringBuffer();
  for (final ch in s.split('')) {
    final i = ar.indexOf(ch);
    if (i >= 0) {
      b.write(i);
    } else if (ch == '٫' || ch == '،' || ch == ',') {
      b.write('.');
    } else {
      b.write(ch);
    }
  }
  return b.toString();
}

const arabicDays = [
  'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'
];

enum QType { essay, complete, mcq, trueFalse, table, matching }

extension QTypeInfo on QType {
  String get title {
    switch (this) {
      case QType.essay:
        return 'مقالي / أسطر إجابة';
      case QType.complete:
        return 'أكمل الفراغات';
      case QType.mcq:
        return 'اختيار من متعدد';
      case QType.trueFalse:
        return 'صح أو خطأ';
      case QType.table:
        return 'جدول';
      case QType.matching:
        return 'توصيل (مطابقة)';
    }
  }

  String get hint {
    switch (this) {
      case QType.essay:
        return 'سؤال بأسطر فارغة للإجابة';
      case QType.complete:
        return 'عدة فقرات تنتهي بنقاط للتعبئة';
      case QType.mcq:
        return 'اختيارات أ ب ج د مع تحديد الإجابة الصحيحة';
      case QType.trueFalse:
        return 'عبارات بجانبها ( ) للصح والخطأ';
      case QType.table:
        return 'جدول فارغ أو مقارنة بعدد صفوف وأعمدة تحددها';
      case QType.matching:
        return 'عمودان للتوصيل بين العناصر';
    }
  }
}

class Question {
  String id;
  QType type;
  String text;
  double score;
  int lines; // أسطر الإجابة للسؤال المقالي
  List<String> items; // الخيارات / العبارات / الفقرات / العمود الأول
  List<String> items2; // العمود الثاني للتوصيل
  List<List<String>> table;
  bool tableHeader;
  int correctIndex; // للاختيار من متعدد (-1 = غير محدد)
  List<bool> tfAnswers; // إجابات الصح/الخطأ (بنفس ترتيب items)
  String modelAnswer; // الإجابة النموذجية للمعلم

  Question({
    String? id,
    required this.type,
    this.text = '',
    this.score = 1,
    this.lines = 3,
    List<String>? items,
    List<String>? items2,
    List<List<String>>? table,
    this.tableHeader = true,
    this.correctIndex = -1,
    List<bool>? tfAnswers,
    this.modelAnswer = '',
  })  : id = id ?? newId(),
        items = items ?? [],
        items2 = items2 ?? [],
        table = table ?? [['', ''], ['', '']],
        tfAnswers = tfAnswers ?? [];

  factory Question.blank(QType type) {
    switch (type) {
      case QType.essay:
        return Question(type: type, lines: 3);
      case QType.complete:
        return Question(type: type, items: ['', '', ''], tfAnswers: [true, true, true]);
      case QType.mcq:
        return Question(
            type: type,
            items: ['', '', '', ''],
            tfAnswers: [true, true, true, true]);
      case QType.trueFalse:
        return Question(type: type, items: ['', '', ''], tfAnswers: [true, true, true]);
      case QType.table:
        return Question(
            type: type,
            table: List.generate(3, (_) => List.filled(3, '', growable: true), growable: true),
            tableHeader: true);
      case QType.matching:
        return Question(
            type: type,
            items: ['', '', ''],
            items2: ['', '', ''],
            tfAnswers: [true, true, true]);
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.name,
        'text': text,
        'score': score,
        'lines': lines,
        'items': items,
        'items2': items2,
        'table': table,
        'tableHeader': tableHeader,
        'correct': correctIndex,
        'tf': tfAnswers,
        'model': modelAnswer,
      };

  factory Question.fromJson(Map<String, dynamic> j) {
    List<String> strs(dynamic v) =>
        (v as List?)?.map((e) => e.toString()).toList() ?? <String>[];
    final items = strs(j['items']);
    var tf = (j['tf'] as List?)?.map((e) => e == true).toList() ?? <bool>[];
    while (tf.length < items.length) {
      tf.add(true);
    }
    return Question(
      id: j['id'] as String?,
      type: QType.values.firstWhere((t) => t.name == j['type'],
          orElse: () => QType.essay),
      text: (j['text'] as String?) ?? '',
      score: ((j['score'] as num?) ?? 1).toDouble(),
      lines: (j['lines'] as int?) ?? 3,
      items: items,
      items2: strs(j['items2']),
      table: (j['table'] as List?)
              ?.map((r) => (r as List).map((e) => e.toString()).toList())
              .toList() ??
          [['', ''], ['', '']],
      tableHeader: (j['tableHeader'] as bool?) ?? true,
      correctIndex: (j['correct'] as int?) ?? -1,
      tfAnswers: tf,
      modelAnswer: (j['model'] as String?) ?? '',
    );
  }

  Question copy() => Question.fromJson(toJson())..id = newId();
}

class ExamHeader {
  String republic;
  String ministry;
  String directorate;
  String school;
  String examTitle;
  String academicYear;
  String subject;
  String grade;
  String section;
  String day;
  String date;
  String duration;
  String teacher;
  int style; // 0 بيضاوي، 1 كلاسيكي بشعار، 2 مبسط
  bool showBasmala;
  bool showStudentLine;
  String? logo; // صورة الشعار base64

  ExamHeader({
    this.republic = 'الجمهورية اليمنية',
    this.ministry = 'وزارة التربية والتعليم',
    this.directorate = '',
    this.school = '',
    this.examTitle = 'اختبار الشهر الأول',
    this.academicYear = '',
    this.subject = '',
    this.grade = '',
    this.section = '',
    this.day = '',
    this.date = '',
    this.duration = 'حصة',
    this.teacher = '',
    this.style = 0,
    this.showBasmala = false,
    this.showStudentLine = true,
    this.logo,
  });

  Map<String, dynamic> toJson() => {
        'republic': republic,
        'ministry': ministry,
        'directorate': directorate,
        'school': school,
        'examTitle': examTitle,
        'academicYear': academicYear,
        'subject': subject,
        'grade': grade,
        'section': section,
        'day': day,
        'date': date,
        'duration': duration,
        'teacher': teacher,
        'style': style,
        'basmala': showBasmala,
        'studentLine': showStudentLine,
        'logo': logo,
      };

  factory ExamHeader.fromJson(Map<String, dynamic> j) {
    String s(String k, String d) => (j[k] as String?) ?? d;
    final d = ExamHeader();
    return ExamHeader(
      republic: s('republic', d.republic),
      ministry: s('ministry', d.ministry),
      directorate: s('directorate', ''),
      school: s('school', ''),
      examTitle: s('examTitle', d.examTitle),
      academicYear: s('academicYear', ''),
      subject: s('subject', ''),
      grade: s('grade', ''),
      section: s('section', ''),
      day: s('day', ''),
      date: s('date', ''),
      duration: s('duration', d.duration),
      teacher: s('teacher', ''),
      style: (j['style'] as int?) ?? 0,
      showBasmala: (j['basmala'] as bool?) ?? false,
      showStudentLine: (j['studentLine'] as bool?) ?? true,
      logo: j['logo'] as String?,
    );
  }
}

class PageSettings {
  bool border;
  bool doubleBorder;
  int borderColor; // ARGB
  double fontScale;
  int numbering; // 0 أ) ب)  | 1 1- 2-  | 2 السؤال الأول
  String instruction;
  String closing;
  bool showTotal;
  bool bubbleSheet;
  bool watermark;
  String watermarkText;
  bool watermarkUseLogo;
  double watermarkOpacity;

  PageSettings({
    this.border = true,
    this.doubleBorder = true,
    this.borderColor = 0xFF1B5E20,
    this.fontScale = 1.0,
    this.numbering = 0,
    this.instruction = '* أجب عن جميع الأسئلة الآتية :',
    this.closing = 'مع تمنياتي لكم بالتوفيق والنجاح',
    this.showTotal = true,
    this.bubbleSheet = false,
    this.watermark = false,
    this.watermarkText = '',
    this.watermarkUseLogo = false,
    this.watermarkOpacity = 0.08,
  });

  Map<String, dynamic> toJson() => {
        'border': border,
        'doubleBorder': doubleBorder,
        'borderColor': borderColor,
        'fontScale': fontScale,
        'numbering': numbering,
        'instruction': instruction,
        'closing': closing,
        'showTotal': showTotal,
        'bubbleSheet': bubbleSheet,
        'watermark': watermark,
        'watermarkText': watermarkText,
        'watermarkUseLogo': watermarkUseLogo,
        'watermarkOpacity': watermarkOpacity,
      };

  factory PageSettings.fromJson(Map<String, dynamic> j) {
    final d = PageSettings();
    return PageSettings(
      border: (j['border'] as bool?) ?? d.border,
      doubleBorder: (j['doubleBorder'] as bool?) ?? d.doubleBorder,
      borderColor: (j['borderColor'] as int?) ?? d.borderColor,
      fontScale: ((j['fontScale'] as num?) ?? d.fontScale).toDouble(),
      numbering: (j['numbering'] as int?) ?? d.numbering,
      instruction: (j['instruction'] as String?) ?? d.instruction,
      closing: (j['closing'] as String?) ?? d.closing,
      showTotal: (j['showTotal'] as bool?) ?? d.showTotal,
      bubbleSheet: (j['bubbleSheet'] as bool?) ?? d.bubbleSheet,
      watermark: (j['watermark'] as bool?) ?? d.watermark,
      watermarkText: (j['watermarkText'] as String?) ?? '',
      watermarkUseLogo: (j['watermarkUseLogo'] as bool?) ?? false,
      watermarkOpacity:
          ((j['watermarkOpacity'] as num?) ?? d.watermarkOpacity).toDouble(),
    );
  }
}

class Exam {
  String id;
  DateTime updated;
  ExamHeader header;
  PageSettings settings;
  List<Question> questions;

  Exam({
    String? id,
    DateTime? updated,
    ExamHeader? header,
    PageSettings? settings,
    List<Question>? questions,
  })  : id = id ?? newId(),
        updated = updated ?? DateTime.now(),
        header = header ?? ExamHeader(),
        settings = settings ?? PageSettings(),
        questions = questions ?? [];

  /// اختبار جديد بقيم افتراضية ذكية (اليوم والتاريخ والعام الدراسي)
  factory Exam.create() {
    final n = DateTime.now();
    final startYear = n.month >= 9 ? n.year : n.year - 1;
    return Exam(
      header: ExamHeader(
        day: arabicDays[n.weekday - 1],
        date: '${n.year}/${n.month}/${n.day}م',
        academicYear: '$startYear - ${startYear + 1}م',
      ),
    );
  }

  double get total => questions.fold(0.0, (s, q) => s + q.score);

  String get title {
    final parts = [header.subject, header.grade]
        .where((s) => s.trim().isNotEmpty)
        .toList();
    return parts.isEmpty ? 'اختبار بدون عنوان' : parts.join(' - ');
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'updated': updated.toIso8601String(),
        'header': header.toJson(),
        'settings': settings.toJson(),
        'questions': questions.map((q) => q.toJson()).toList(),
      };

  factory Exam.fromJson(Map<String, dynamic> j) => Exam(
        id: j['id'] as String?,
        updated: DateTime.tryParse((j['updated'] as String?) ?? ''),
        header: ExamHeader.fromJson(
            (j['header'] as Map?)?.cast<String, dynamic>() ?? {}),
        settings: PageSettings.fromJson(
            (j['settings'] as Map?)?.cast<String, dynamic>() ?? {}),
        questions: (j['questions'] as List?)
                ?.map((e) => Question.fromJson((e as Map).cast<String, dynamic>()))
                .toList() ??
            [],
      );
}

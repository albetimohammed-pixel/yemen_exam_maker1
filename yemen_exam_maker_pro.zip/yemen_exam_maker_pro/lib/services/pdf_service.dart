import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/exam.dart';

/// الخطوط تُحمَّل من داخل التطبيق (بدون إنترنت).
/// لتحسين الشكل: ضع خط Amiri أو Cairo في assets/fonts بالأسماء الموضحة أدناه
/// وسيُستخدم تلقائياً بدل DejaVu.
class _Fonts {
  final pw.Font regular;
  final pw.Font bold;
  _Fonts(this.regular, this.bold);

  static _Fonts? _cache;

  static Future<pw.Font?> _try(List<String> paths) async {
    for (final p in paths) {
      try {
        final data = await rootBundle.load(p);
        return pw.Font.ttf(data);
      } catch (_) {
        // جرّب الخط التالي
      }
    }
    return null;
  }

  static Future<_Fonts> load() async {
    if (_cache != null) return _cache!;
    final regular = await _try([
          'assets/fonts/Amiri-Regular.ttf',
          'assets/fonts/Cairo-Regular.ttf',
          'assets/fonts/DejaVuSans.ttf',
        ]) ??
        pw.Font.helvetica();
    final bold = await _try([
          'assets/fonts/Amiri-Bold.ttf',
          'assets/fonts/Cairo-Bold.ttf',
          'assets/fonts/DejaVuSans-Bold.ttf',
        ]) ??
        regular;
    return _cache = _Fonts(regular, bold);
  }
}

class PdfService {
  /// [answerKey] = true يُنتج نموذج الإجابة للمعلم بدل ورقة الطالب.
  static Future<Uint8List> build(Exam exam, {bool answerKey = false}) async {
    final fonts = await _Fonts.load();
    return _Builder(exam, fonts, answerKey).build();
  }
}

const _letters = ['أ', 'ب', 'ج', 'د', 'هـ', 'و', 'ز', 'ح', 'ط', 'ي', 'ك', 'ل'];
const _ordinals = [
  'الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس',
  'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر'
];

String _letter(int i) => i < _letters.length ? _letters[i] : '${i + 1}';

class _Builder {
  final Exam e;
  final _Fonts f;
  final bool key;
  _Builder(this.e, this.f, this.key);

  PageSettings get s => e.settings;
  ExamHeader get h => e.header;
  double get fs => 11 * s.fontScale;
  PdfColor get frameColor => PdfColor.fromInt(0xFF000000 | (s.borderColor & 0xFFFFFF));

  // ---------------------------------------------------------------- أدوات
  pw.Widget _t(String text,
      {double? size,
      bool bold = false,
      pw.TextAlign align = pw.TextAlign.right,
      PdfColor? color}) {
    return pw.Text(
      text,
      textDirection: pw.TextDirection.rtl,
      textAlign: align,
      style: pw.TextStyle(
        font: bold ? f.bold : f.regular,
        fontSize: size ?? fs,
        color: color ?? PdfColors.black,
      ),
    );
  }

  pw.Widget _gap(double v) => pw.SizedBox(height: v);

  String _label(int i) {
    switch (s.numbering) {
      case 1:
        return '${i + 1}-';
      case 2:
        return i < _ordinals.length ? 'السؤال ${_ordinals[i]}:' : 'السؤال ${i + 1}:';
      default:
        return '${_letter(i)})';
    }
  }

  pw.MemoryImage? get _logo {
    final b = h.logo;
    if (b == null || b.isEmpty) return null;
    try {
      return pw.MemoryImage(base64Decode(b));
    } catch (_) {
      return null;
    }
  }

  // ---------------------------------------------------------------- الصفحة
  pw.PageTheme _pageTheme() {
    return pw.PageTheme(
      pageFormat: PdfPageFormat.a4,
      textDirection: pw.TextDirection.rtl,
      theme: pw.ThemeData.withFont(base: f.regular, bold: f.bold),
      margin: pw.EdgeInsets.fromLTRB(
          s.border ? 34 : 28, s.border ? 34 : 28, s.border ? 34 : 28, s.border ? 38 : 32),
      buildBackground: (ctx) => _background(),
    );
  }

  pw.Widget _background() {
    final kids = <pw.Widget>[];
    if (s.border) {
      kids.add(pw.Positioned(
        left: 14,
        top: 14,
        right: 14,
        bottom: 14,
        child: pw.Container(
          decoration: pw.BoxDecoration(
            border: pw.Border.all(color: frameColor, width: s.doubleBorder ? 2.4 : 1.6),
          ),
          child: s.doubleBorder
              ? pw.Container(
                  margin: const pw.EdgeInsets.all(3),
                  decoration: pw.BoxDecoration(
                    border: pw.Border.all(color: frameColor, width: 0.7),
                  ),
                )
              : null,
        ),
      ));
    }
    final wm = _watermark();
    if (wm != null) kids.add(pw.Center(child: wm));
    return pw.FullPage(
      ignoreMargins: true,
      child: pw.Stack(fit: pw.StackFit.expand, children: kids),
    );
  }

  pw.Widget? _watermark() {
    if (!s.watermark) return null;
    pw.Widget? content;
    if (s.watermarkUseLogo && _logo != null) {
      content = pw.Image(_logo!, width: 280);
    } else if (s.watermarkText.trim().isNotEmpty) {
      content = pw.Text(
        s.watermarkText.trim(),
        textDirection: pw.TextDirection.rtl,
        style: pw.TextStyle(font: f.bold, fontSize: 60, color: PdfColors.grey700),
      );
    }
    if (content == null) return null;
    return pw.Opacity(
      opacity: s.watermarkOpacity.clamp(0.02, 0.4).toDouble(),
      child: pw.Transform.rotate(angle: -math.pi / 6, child: content),
    );
  }

  // ---------------------------------------------------------------- البناء
  Future<Uint8List> build() async {
    final doc = pw.Document(
      title: e.title,
      author: h.teacher.isEmpty ? 'صانع الاختبارات اليمنية' : h.teacher,
    );

    doc.addPage(pw.MultiPage(
      pageTheme: _pageTheme(),
      footer: (ctx) => pw.Container(
        alignment: pw.Alignment.center,
        margin: const pw.EdgeInsets.only(top: 4),
        child: _t('${ctx.pageNumber} / ${ctx.pagesCount}',
            size: 8, align: pw.TextAlign.center, color: PdfColors.grey700),
      ),
      build: (ctx) => [
        if (h.showBasmala)
          pw.Padding(
            padding: const pw.EdgeInsets.only(bottom: 5),
            child: _t('بسم الله الرحمن الرحيم',
                size: fs + 2, bold: true, align: pw.TextAlign.center),
          ),
        _header(),
        _studentBar(),
        _gap(6),
        _questionsTable(),
        if (s.closing.trim().isNotEmpty)
          pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.all(6),
            decoration: const pw.BoxDecoration(
              border: pw.Border(
                left: pw.BorderSide(width: 0.9),
                right: pw.BorderSide(width: 0.9),
                bottom: pw.BorderSide(width: 0.9),
              ),
            ),
            child: _t(s.closing, bold: true, align: pw.TextAlign.center),
          ),
      ],
    ));

    if (!key && s.bubbleSheet) {
      final entries = _bubbleEntries();
      if (entries.isNotEmpty) {
        doc.addPage(pw.MultiPage(
          pageTheme: _pageTheme(),
          build: (ctx) => [
            _t('ورقة الإجابة (تظليل)', size: fs + 4, bold: true, align: pw.TextAlign.center),
            _gap(2),
            _t('${h.subject} - ${h.grade}', align: pw.TextAlign.center),
            _gap(8),
            _studentBar(forceStudent: true),
            _gap(10),
            ...entries,
          ],
        ));
      }
    }
    return doc.save();
  }

  // ---------------------------------------------------------------- الترويسة
  pw.Widget _header() {
    switch (h.style) {
      case 1:
        return _headerClassic();
      case 2:
        return _headerMinimal();
      default:
        return _headerOval();
    }
  }

  String get _titleText => key ? '${h.examTitle} — نموذج الإجابة' : h.examTitle;
  String get _gradeYear {
    final parts = <String>[
      if (h.grade.isNotEmpty) h.grade,
      if (h.academicYear.isNotEmpty) 'للعام ${h.academicYear}',
    ];
    return parts.join(' - ');
  }

  pw.Widget _line(String label, String value, {bool bold = false}) {
    if (value.trim().isEmpty) return pw.SizedBox();
    return _t(label.isEmpty ? value : '$label : $value',
        size: fs - 1.5, bold: bold, align: pw.TextAlign.center);
  }

  pw.Widget _headerOval() {
    const side = pw.BorderSide(width: 1.1);
    final minH = pw.BoxConstraints(minHeight: 54 * s.fontScale);
    return pw.Container(
      decoration: pw.BoxDecoration(border: pw.Border.all(width: 1.1)),
      child: pw.Row(
        textDirection: pw.TextDirection.rtl,
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Expanded(
            flex: 3,
            child: pw.Container(
              constraints: minH,
              padding: const pw.EdgeInsets.all(5),
              child: pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: [
                  _line('', h.school, bold: true),
                  _line('مديرية', h.directorate),
                  _line('الزمن', h.duration),
                ],
              ),
            ),
          ),
          pw.Expanded(
            flex: 4,
            child: pw.Container(
              constraints: minH,
              padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 5),
              decoration: const pw.BoxDecoration(
                border: pw.Border(left: side, right: side),
              ),
              child: pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: [
                  pw.Container(
                    padding: const pw.EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                    decoration: pw.BoxDecoration(
                      border: pw.Border.all(width: 1.1),
                      borderRadius: const pw.BorderRadius.all(pw.Radius.circular(18)),
                    ),
                    child: _t(_titleText,
                        size: fs - 0.5, bold: true, align: pw.TextAlign.center),
                  ),
                  _gap(3),
                  _t(_gradeYear, size: fs - 2, bold: true, align: pw.TextAlign.center),
                ],
              ),
            ),
          ),
          pw.Expanded(
            flex: 3,
            child: pw.Container(
              constraints: minH,
              padding: const pw.EdgeInsets.all(5),
              child: pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: [
                  _line('المادة', h.subject, bold: true),
                  _line('اليوم', h.day),
                  _line('التاريخ', h.date),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  pw.Widget _headerClassic() {
    final logo = _logo;
    return pw.Container(
      padding: const pw.EdgeInsets.all(6),
      decoration: pw.BoxDecoration(border: pw.Border.all(width: 1.1)),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: [
          pw.Row(
            textDirection: pw.TextDirection.rtl,
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              pw.Expanded(
                flex: 3,
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.stretch,
                  children: [
                    _sideLine(h.republic, bold: true),
                    _sideLine(h.ministry),
                    _sideLine(h.directorate.isEmpty ? '' : 'مديرية ${h.directorate}'),
                    _sideLine(h.school, bold: true),
                  ],
                ),
              ),
              pw.Expanded(
                flex: 2,
                child: pw.Center(
                  child: logo != null
                      ? pw.Image(logo, height: 56, fit: pw.BoxFit.contain)
                      : pw.SizedBox(height: 56),
                ),
              ),
              pw.Expanded(
                flex: 3,
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.stretch,
                  children: [
                    _sideLine(h.subject.isEmpty ? '' : 'المادة : ${h.subject}', bold: true),
                    _sideLine(h.grade.isEmpty ? '' : 'الصف : ${h.grade}'),
                    _sideLine(h.date.isEmpty ? '' : 'التاريخ : ${h.date}'),
                    _sideLine(h.duration.isEmpty ? '' : 'الزمن : ${h.duration}'),
                  ],
                ),
              ),
            ],
          ),
          _gap(5),
          pw.Center(
            child: pw.Container(
              padding: const pw.EdgeInsets.symmetric(horizontal: 16, vertical: 3),
              decoration: pw.BoxDecoration(
                border: pw.Border.all(width: 1),
                borderRadius: const pw.BorderRadius.all(pw.Radius.circular(8)),
              ),
              child: _t(
                  h.academicYear.isEmpty ? _titleText : '$_titleText - ${h.academicYear}',
                  bold: true,
                  align: pw.TextAlign.center),
            ),
          ),
        ],
      ),
    );
  }

  pw.Widget _sideLine(String text, {bool bold = false}) {
    if (text.trim().isEmpty) return pw.SizedBox();
    return _t(text, size: fs - 1.5, bold: bold);
  }

  pw.Widget _headerMinimal() {
    return pw.Container(
      padding: const pw.EdgeInsets.all(6),
      decoration: pw.BoxDecoration(border: pw.Border.all(width: 1.1)),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: [
          pw.Row(
            textDirection: pw.TextDirection.rtl,
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              _t([h.republic, h.school].where((x) => x.isNotEmpty).join(' - '),
                  size: fs - 1.5, bold: true),
              _t(_titleText, size: fs - 1.5, bold: true),
            ],
          ),
          pw.Divider(thickness: 0.8, height: 8),
          pw.Row(
            textDirection: pw.TextDirection.rtl,
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              _t('المادة: ${h.subject}', size: fs - 2),
              _t('الصف: ${h.grade}', size: fs - 2),
              _t('الزمن: ${h.duration}', size: fs - 2),
              _t('التاريخ: ${h.date}', size: fs - 2),
            ],
          ),
        ],
      ),
    );
  }

  pw.Widget _studentBar({bool forceStudent = false}) {
    const side = pw.BorderSide(width: 1.1);
    if (key) {
      return pw.Container(
        width: double.infinity,
        padding: const pw.EdgeInsets.symmetric(vertical: 5),
        decoration: const pw.BoxDecoration(
          border: pw.Border(left: side, right: side, bottom: side),
        ),
        child: _t('نموذج الإجابة — للمعلم فقط',
            bold: true, align: pw.TextAlign.center, color: PdfColors.red800),
      );
    }
    if (!h.showStudentLine && !forceStudent) return pw.SizedBox();
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: const pw.BoxDecoration(
        border: pw.Border(left: side, right: side, bottom: side),
      ),
      child: pw.Row(
        textDirection: pw.TextDirection.rtl,
        children: [
          pw.Expanded(
            flex: 4,
            child: _t('اسم الطالب : ${'.' * 55}', bold: true),
          ),
          pw.Expanded(
            flex: 1,
            child: _t('الشعبة ( ${h.section.isEmpty ? '     ' : h.section} )', bold: true),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------- جدول الأسئلة
  pw.Widget _cell(pw.Widget child, {double pad = 6}) =>
      pw.Padding(padding: pw.EdgeInsets.all(pad), child: child);

  pw.Widget _questionsTable() {
    final rows = <pw.TableRow>[
      pw.TableRow(
        repeat: true,
        decoration: const pw.BoxDecoration(color: PdfColors.grey200),
        children: [
          _cell(_t(s.instruction, bold: true), pad: 5),
          _cell(_t('الدرجة', bold: true, align: pw.TextAlign.center), pad: 5),
        ],
      ),
    ];

    if (e.questions.isEmpty) {
      rows.add(pw.TableRow(children: [
        _cell(_t('لا توجد أسئلة مضافة بعد.', align: pw.TextAlign.center), pad: 20),
        _cell(pw.SizedBox()),
      ]));
    }

    for (var i = 0; i < e.questions.length; i++) {
      final q = e.questions[i];
      rows.add(pw.TableRow(
        verticalAlignment: pw.TableCellVerticalAlignment.middle,
        children: [
          _cell(key ? _answerBody(q, i) : _questionBody(q, i)),
          _cell(_t(fmtScore(q.score), bold: true, size: fs + 1, align: pw.TextAlign.center)),
        ],
      ));
    }

    if (s.showTotal && e.questions.isNotEmpty) {
      rows.add(pw.TableRow(
        decoration: const pw.BoxDecoration(color: PdfColors.grey200),
        verticalAlignment: pw.TableCellVerticalAlignment.middle,
        children: [
          _cell(_t('المجموع الكلي', bold: true, align: pw.TextAlign.center), pad: 5),
          _cell(_t(fmtScore(e.total), bold: true, align: pw.TextAlign.center), pad: 5),
        ],
      ));
    }

    return pw.Table(
      border: pw.TableBorder.all(width: 0.9),
      columnWidths: {
        0: const pw.FlexColumnWidth(1),
        1: const pw.FixedColumnWidth(46),
      },
      defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
      children: rows,
    );
  }

  // ---------------------------------------------------------------- أجسام الأسئلة
  pw.Widget _questionBody(Question q, int i) {
    final kids = <pw.Widget>[_t('${_label(i)} ${q.text}', bold: true), _gap(4)];

    switch (q.type) {
      case QType.essay:
        for (var k = 0; k < q.lines; k++) {
          kids.add(pw.Container(
            height: fs * 1.9,
            margin: const pw.EdgeInsets.symmetric(horizontal: 6),
            decoration: const pw.BoxDecoration(
              border: pw.Border(
                  bottom: pw.BorderSide(width: 0.5, color: PdfColors.grey600)),
            ),
          ));
        }
        break;

      case QType.complete:
        for (var k = 0; k < q.items.length; k++) {
          final t = q.items[k];
          final hasBlank = t.contains('...') || t.contains('___');
          kids.add(pw.Padding(
            padding: const pw.EdgeInsets.only(right: 10, bottom: 3),
            child: _t('${k + 1}- $t${hasBlank ? '' : ' ${'.' * 28}'}', size: fs - 0.5),
          ));
        }
        break;

      case QType.mcq:
        final n = q.items.length;
        final maxLen = q.items.fold<int>(0, (m, x) => x.length > m ? x.length : m);
        final per = maxLen <= 14 ? (n >= 4 ? 4 : (n < 1 ? 1 : n)) : (maxLen <= 32 ? 2 : 1);
        for (var r = 0; r < n; r += per) {
          kids.add(pw.Padding(
            padding: const pw.EdgeInsets.only(right: 10, bottom: 3),
            child: pw.Row(
              textDirection: pw.TextDirection.rtl,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                for (var k = 0; k < per; k++)
                  pw.Expanded(
                    child: r + k < n
                        ? _t('${_letter(r + k)}) ${q.items[r + k]}', size: fs - 0.5)
                        : pw.SizedBox(),
                  ),
              ],
            ),
          ));
        }
        break;

      case QType.trueFalse:
        for (var k = 0; k < q.items.length; k++) {
          kids.add(pw.Padding(
            padding: const pw.EdgeInsets.only(right: 10, bottom: 3),
            child: pw.Row(
              textDirection: pw.TextDirection.rtl,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Expanded(child: _t('${k + 1}- ${q.items[k]}', size: fs - 0.5)),
                pw.SizedBox(width: 8),
                _t('(        )', size: fs - 0.5),
              ],
            ),
          ));
        }
        break;

      case QType.table:
        final rows = q.table.where((r) => r.isNotEmpty).toList();
        if (rows.isNotEmpty) {
          final cols = rows.map((r) => r.length).reduce(math.max);
          kids.add(pw.Table(
            border: pw.TableBorder.all(width: 0.6),
            children: [
              for (var r = 0; r < rows.length; r++)
                pw.TableRow(
                  decoration: (r == 0 && q.tableHeader)
                      ? const pw.BoxDecoration(color: PdfColors.grey200)
                      : null,
                  children: [
                    for (var c = 0; c < cols; c++)
                      pw.Container(
                        constraints: const pw.BoxConstraints(minHeight: 20),
                        padding: const pw.EdgeInsets.all(4),
                        alignment: pw.Alignment.center,
                        child: _t(c < rows[r].length ? rows[r][c] : '',
                            size: fs - 1,
                            bold: r == 0 && q.tableHeader,
                            align: pw.TextAlign.center),
                      ),
                  ],
                ),
            ],
          ));
        }
        break;

      case QType.matching:
        final pairs = math.max(q.items.length, q.items2.length);
        for (var k = 0; k < pairs; k++) {
          kids.add(pw.Padding(
            padding: const pw.EdgeInsets.only(right: 10, bottom: 4),
            child: pw.Row(
              textDirection: pw.TextDirection.rtl,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Expanded(
                    flex: 5,
                    child: _t(k < q.items.length ? '${k + 1}- ${q.items[k]}' : '',
                        size: fs - 0.5)),
                _t('(     )', size: fs - 0.5),
                pw.SizedBox(width: 14),
                pw.Expanded(
                    flex: 5,
                    child: _t(k < q.items2.length ? '${_letter(k)}- ${q.items2[k]}' : '',
                        size: fs - 0.5)),
              ],
            ),
          ));
        }
        break;
    }

    return pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.stretch, children: kids);
  }

  pw.Widget _answerBody(Question q, int i) {
    final kids = <pw.Widget>[_t('${_label(i)} ${q.text}', bold: true), _gap(3)];
    final green = PdfColors.green800;

    if (q.type == QType.mcq) {
      final c = q.correctIndex;
      kids.add(c >= 0 && c < q.items.length
          ? _t('الإجابة الصحيحة: ${_letter(c)}) ${q.items[c]}', color: green, bold: true)
          : _t('— لم تُحدَّد الإجابة الصحيحة —', color: PdfColors.grey700));
    } else if (q.type == QType.trueFalse) {
      for (var k = 0; k < q.items.length; k++) {
        final ok = k < q.tfAnswers.length ? q.tfAnswers[k] : true;
        kids.add(pw.Padding(
          padding: const pw.EdgeInsets.only(right: 10, bottom: 2),
          child: _t('${k + 1}- ${q.items[k]}   ( ${ok ? 'صح' : 'خطأ'} )',
              size: fs - 0.5, color: ok ? green : PdfColors.red800),
        ));
      }
    }

    if (q.modelAnswer.trim().isNotEmpty) {
      kids.add(_t(q.modelAnswer.trim(), color: green));
    } else if (q.type != QType.mcq && q.type != QType.trueFalse) {
      kids.add(_t('— لا توجد إجابة نموذجية مسجّلة —', color: PdfColors.grey700));
    }
    return pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.stretch, children: kids);
  }

  // ---------------------------------------------------------------- ورقة التظليل
  pw.Widget _bubble(String label) => pw.Container(
        width: 16,
        height: 16,
        margin: const pw.EdgeInsets.symmetric(horizontal: 3),
        alignment: pw.Alignment.center,
        decoration: pw.BoxDecoration(
          shape: pw.BoxShape.circle,
          border: pw.Border.all(width: 0.8),
        ),
        child: pw.Text(label,
            textDirection: pw.TextDirection.rtl,
            style: pw.TextStyle(font: f.regular, fontSize: label.length > 1 ? 5.5 : 8)),
      );

  List<pw.Widget> _bubbleEntries() {
    final cells = <pw.Widget>[];
    var n = 0;
    for (final q in e.questions) {
      if (q.type == QType.mcq) {
        n++;
        final count = q.items.length.clamp(2, _letters.length);
        cells.add(_bubbleRow(n, [for (var k = 0; k < count; k++) _bubble(_letters[k])]));
      } else if (q.type == QType.trueFalse) {
        for (var k = 0; k < q.items.length; k++) {
          n++;
          cells.add(_bubbleRow(n, [_bubble('صح'), _bubble('خطأ')]));
        }
      }
    }
    final rows = <pw.Widget>[];
    for (var i = 0; i < cells.length; i += 2) {
      rows.add(pw.Padding(
        padding: const pw.EdgeInsets.only(bottom: 8),
        child: pw.Row(
          textDirection: pw.TextDirection.rtl,
          children: [
            pw.Expanded(child: cells[i]),
            pw.Expanded(child: i + 1 < cells.length ? cells[i + 1] : pw.SizedBox()),
          ],
        ),
      ));
    }
    return rows;
  }

  pw.Widget _bubbleRow(int n, List<pw.Widget> bubbles) => pw.Row(
        textDirection: pw.TextDirection.rtl,
        children: [
          pw.SizedBox(width: 26, child: _t('$n', bold: true)),
          ...bubbles,
        ],
      );
}

import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/exam.dart';

/// تخزين دائم للاختبارات على الجهاز (JSON داخل SharedPreferences).
/// العمليات تُنفّذ بالتسلسل لتفادي تعارض الحفظ التلقائي.
class ExamRepository {
  ExamRepository._();
  static final ExamRepository instance = ExamRepository._();

  static const _key = 'exams_v2';
  Future<void> _lock = Future<void>.value();

  Future<T> _run<T>(Future<T> Function() f) {
    final r = _lock.then((_) => f());
    _lock = r.then((_) {}, onError: (_) {});
    return r;
  }

  Future<List<Exam>> loadAll() => _run(_read);

  Future<List<Exam>> _read() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return <Exam>[];
    try {
      final list = (jsonDecode(raw) as List)
          .map((e) => Exam.fromJson((e as Map).cast<String, dynamic>()))
          .toList();
      list.sort((a, b) => b.updated.compareTo(a.updated));
      return list;
    } catch (_) {
      return <Exam>[];
    }
  }

  Future<void> _write(List<Exam> list) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(list.map((e) => e.toJson()).toList()));
  }

  Future<void> upsert(Exam exam) => _run(() async {
        exam.updated = DateTime.now();
        final list = await _read();
        final i = list.indexWhere((e) => e.id == exam.id);
        if (i >= 0) {
          list[i] = exam;
        } else {
          list.insert(0, exam);
        }
        await _write(list);
      });

  Future<void> delete(String id) => _run(() async {
        final list = await _read();
        list.removeWhere((e) => e.id == id);
        await _write(list);
      });
}
